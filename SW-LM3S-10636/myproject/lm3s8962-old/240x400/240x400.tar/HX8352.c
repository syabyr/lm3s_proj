#include "inc/hw_gpio.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "grlib/grlib.h"
#include "HX8352.h"


//总线数据写入,将16bit的数据挂载数据总线上,然后使能写信号
void WriteData(unsigned short usData)
{
	//将数据写入数据总线,低8位写在PORTA上,高8位写在PORTB上.
	HWREG(LCD_DATAH_BASE+GPIO_O_DATA+(0xff<<2))=usData>>8;
	HWREG(LCD_DATAL_BASE+GPIO_O_DATA+(0xff<<2))=usData;
	GPIOPinWrite(GPIO_PORTC_BASE,0x80,(usData>>8)&0x80);
	//使能读信号,将信号线拉低后再拉高
	LCD_WRITE_ON;
	LCD_WRITE_OFF;
}

//总线数据读取,将总线设置为输入,使能读信号,然后读入数据,最后将总线设置为输出.
unsigned short ReadData(void)
{
	unsigned short usData=0;
	//将总线设置为输入
	HWREG(LCD_DATAH_BASE+GPIO_O_DIR)=0x00;
	HWREG(LCD_DATAL_BASE+GPIO_O_DIR)=0x00;
	HWREG(GPIO_PORTC_BASE+GPIO_O_DIR)&=0x7F;
	//拉低读信号
	LCD_READ_ON;
	//读取数据
	usData=HWREG(LCD_DATAL_BASE+GPIO_O_DATA+(0xff<<2));
	usData|=HWREG(LCD_DATAH_BASE+GPIO_O_DATA+(0xff<<2))<<8;
	usData|=(HWREG(LCD_DATAH_BASE+GPIO_O_DATA+(0xff<<2))<<8)&0x80;
	//拉高读信号
	LCD_READ_OFF;
	//将总线设置为输出端口
	HWREG(LCD_DATAL_BASE+GPIO_O_DIR)=0xff;
	HWREG(LCD_DATAH_BASE+GPIO_O_DIR)=0xff;
	HWREG(GPIO_PORTC_BASE+GPIO_O_DIR)|=0x80;

	return (usData);
}

//写命令,8bit的命令挂载数据总线的低8位,使能寄存器选择信号,再使能写数据信号.
void WriteCommand(unsigned char ucData)
{
	//将数据高8bit清零,低8bit载入数据
	HWREG(LCD_DATAL_BASE+GPIO_O_DATA+(0xff<<2))=ucData;
	//拉低寄存器选择信号,然后使能写信号
	LCD_RS_ON;
	LCD_WRITE_ON;
	LCD_WRITE_OFF;
	LCD_RS_OFF;
}
/*
//读寄存器的值,写命令到系统,然后返回寄存器的值
static unsigned short ReadRegister(unsigned char ucIndex)
{
	WriteCommand(ucIndex);
	return (ReadData());
}
*/
//写寄存器的地址,然后写入要写入到这个寄存器的数据,ucIndex为寄存器的地址
static void WriteRegister(unsigned char ucIndex,unsigned short usValue)
{
	WriteCommand(ucIndex);
	WriteData(usValue);
}

//打开背光
void ILI9481BacklightOn(void)
{
	HWREG(LCD_BL_BASE+GPIO_O_DATA+(LCD_BL_PIN<<2))=LCD_BL_PIN;
}

//关闭背光
void ILI9481BacklightOff(void)
{
	HWREG(LCD_BL_BASE+GPIO_O_DATA+(LCD_BL_PIN<<2))=0;
}

//复位液晶

void LCDInit(void)
{
	unsigned long ulClockMS;
	ulClockMS = SysCtlClockGet()/(3*1000);
	//使能要连接的端口
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOG);


	//设置这些管脚为输出,以及他们的默认值
	//数据低8bit
	GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE,0xff);	//0B1111 1111
	GPIOPinWrite(GPIO_PORTA_BASE,0xff,0x00);
	//数据高8bit
	GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE,0x7f);	//0B0111 1111
	GPIOPinWrite(GPIO_PORTB_BASE,0x7f,0x00);
	//PC6,背光,默认背光关闭,等会要打开
	GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE,0xE0);	//0B1110 0000
	GPIOPinWrite(GPIO_PORTC_BASE,0xE0,0x40);		//0B0100 0000
	//RS,WR,RD信号,PF0,PF1,PF2,默认都为高电平
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE,0x07);	//0B0000 0111
	GPIOPinWrite(GPIO_PORTF_BASE,0x07,0x07);
	//RESET复位信号,PG0,默认为高电平
	GPIOPinTypeGPIOOutput(GPIO_PORTG_BASE,0x01);
	GPIOPinWrite(GPIO_PORTG_BASE,0x01,0x01);
	SELECT_LCD;

	//复位部分
	SysCtlDelay(100*ulClockMS);

	GPIOPinWrite(GPIO_PORTG_BASE,0x01,0x00);	//拉低复位信号
	SysCtlDelay(10*ulClockMS);
	GPIOPinWrite(GPIO_PORTG_BASE,0x01,0x01);	//拉高复位信号

	SysCtlDelay(100*ulClockMS);

	//初始化命令部分
	WriteRegister(0x0083,0x0002);	//test mode=1,内部寄存器能够接受新的设置
	WriteRegister(0x0085,0x0002); // VDC_SEL=111.VDDD的电压设置
	//Source gamma resistor setting register
	WriteRegister(0x008B,0x0000); // STBA[15:8]=0x00
	WriteRegister(0x008C,0x0033); // STBA[7]=1, STBA[5:4]=01, STBA[1:0]=11
	WriteRegister(0x0091,0x0001); // DCDC_and_Display CLK SYNC=1,

	//结束测试模式
	WriteRegister(0x0083,0x0000); // TESTM=0
	// Gamma Setting
	WriteRegister(0x003E,0x00f0); //γ center adjustment register for positive 
	WriteRegister(0x003F,0x0007); //γ center adjustment register for negative 
	WriteRegister(0x0040,0x0000); //γ macro adjustment register for positive 
	WriteRegister(0x0041,0x0043); //γ macro adjustment register for positive 
	WriteRegister(0x0042,0x0016); //γ macro adjustment register for positive 
	WriteRegister(0x0043,0x0016); //γ macro adjustment register for negative 
	WriteRegister(0x0044,0x0043); //γ macro adjustment register for negative 
	WriteRegister(0x0045,0x0077); //γ macro adjustment register for negative 
	WriteRegister(0x0046,0x0000); //γ offset adjustment register for positive 
	WriteRegister(0x0047,0x001e); //γ offset adjustment register for positive 
	WriteRegister(0x0048,0x000f); //γ offset adjustment register for negative 
	WriteRegister(0x0049,0x0000); //γ offset adjustment register for negative 

	// Power Supply Setting
	WriteRegister(0x0017,0x0011); // RADJ=1001, OSC_EN=1    0071,设置内部振荡器的频率
	WriteRegister(0x0023,0x0001); //TEON=1,Tearing-Effect mode
	WriteRegister(0x002B,0x0053); // N_DCDC=0x7D,Normal mode,普通模式下的分频
	SysCtlDelay(100*ulClockMS);
	WriteRegister(0x001B,0x0014); // BT=0100, AP=100
	WriteRegister(0x001A,0x0030); // VC3=000, VC1=101 
	WriteRegister(0x001C,0x000c); // PON=1, VRH=0110 //0c
	WriteRegister(0x001D,0x000b); //BGP=1111 
	WriteRegister(0x001F,0x0050); // VCM=1010101          0053
	SysCtlDelay(20*ulClockMS);
	WriteRegister(0x0019,0x000A); // GASENB=0, PON=0, DK=1, XDK=0, VLCD_TRI=0, STB=0 
	WriteRegister(0x0019,0x001A); // GASENB=0, PON=0, DK=0, XDK=0, VLCD_TRI=0, STB=0 
	SysCtlDelay(40*ulClockMS);
	WriteRegister(0x0019,0x0012); // GASENB=0, DK=0, XDK=1, VLCD_TRI=0, STB=0, 
	//VLCD=2XVCI by 2 CAPs 
	SysCtlDelay(80*ulClockMS);
	WriteRegister(0x001E,0x002b); // VCOMG=1, VDV=10000     002b
	// DGC Function Enable
	//WriteRegister(0x5A,0x01);
	//GC_PA_REG(0x5C);
	//Window set
	WriteRegister(0x0002,0x0000); // Column Address Start Register, High 8 bit 
	WriteRegister(0x0003,0x0000); // Column Address Start Register, Low 8bit 
	WriteRegister(0x0004,0x0000); // Column Address end Register, High 8 bit 
	WriteRegister(0x0005,0x00EF); // Column Address end Start Register, Low 8 bit 
	WriteRegister(0x0006,0x0000); // Row Address Start Register, High 8 bit 
	WriteRegister(0x0007,0x0000); // Row Address Start Register, Low 8bit 
	WriteRegister(0x0008,0x0001); // Row Address end Register, High 8 bit 
	WriteRegister(0x0009,0x008F); // Row Address end Register, Low 8bit 
	// Display ON Setting
	WriteRegister(0x003C,0x00FF); // N_SAP=1100 000
	WriteRegister(0x003D,0x000e); // I_SAP =1100 0000
	WriteRegister(0x0034,0x0038); // EQS=1000 0111
	WriteRegister(0x0035,0x0038); // EQP=0011 1000
	WriteRegister(0x0024,0x0038); // GON=1, DTE=1, D=10
	SysCtlDelay(40*ulClockMS);
	WriteRegister(0x0024,0x003C); // GON=1, DTE=1, D=11
	WriteRegister(0x0016,0x0000); // BGR=1    1c
	WriteRegister(0x0001,0x0002); // INVON=0, NORNO=1
	WriteRegister(0x0055,0x0002);
	WriteCommand(0x0022);

}



void TestPixel(void)
{
	//起始列
	WriteRegister(0x0003,10);
	WriteRegister(0x0005,11);
	//起始行
	WriteRegister(0x0007,10);
	WriteRegister(0x0009,11);
	WriteCommand(0x0022);
	WriteData(0xffff);

	WriteRegister(0x0003,20);
	WriteRegister(0x0005,21);
	//起始行
	WriteRegister(0x0007,20);
	WriteRegister(0x0009,21);
	WriteCommand(0x0022);
	WriteData(0xffff);

	WriteRegister(0x0003,30);
	WriteRegister(0x0005,31);
	//起始行
	WriteRegister(0x0007,30);
	WriteRegister(0x0009,31);
	WriteCommand(0x0022);
	WriteData(0xffff);

	WriteRegister(0x0003,10);
	WriteRegister(0x0005,10);
	//起始行
	WriteRegister(0x0007,30);
	WriteRegister(0x0009,30);
	WriteCommand(0x0022);
	WriteData(0xffff);
}

void TestShift(void)
{
	unsigned int i,j;
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(0);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(1);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(2);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(4);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(8);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(16);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(32);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(64);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(128);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(256);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(512);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(1024);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(2048);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(4096);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(8192);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(16384);
	};
	for (i=0;i<15;i++)
	{
		for(j=0;j<240;j++)
		WriteData(32768);
	};

}


void TestRGB(void)
{
	int i,j;
	for (i=0;i<100;i++)
	{
		for(j=0;j<240;j++)
		//WriteData(0x001f^0xffff);
		WriteData(0x001f);
	};
	WriteCommand(0x0022);
	for (i=0;i<100;i++)
	{
		for(j=0;j<240;j++)
		//WriteData(0x07e0^0xffff);
		WriteData(0x07e0);
	};
	for (i=0;i<100;i++)
	{
		for(j=0;j<240;j++)
		//WriteData(0x0f800^0xffff);
		WriteData(0x0f800);
	};

}
