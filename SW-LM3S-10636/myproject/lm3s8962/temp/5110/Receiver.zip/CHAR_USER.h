#define uchar unsigned char
#define uint unsigned int

extern unsigned char const ASCII326[][6];
extern unsigned char const ASCII[][6];  
extern unsigned char const dip_ico[];
extern unsigned char const HZ12[][24];
extern unsigned char const Num[][60];
extern unsigned char const TI[];


