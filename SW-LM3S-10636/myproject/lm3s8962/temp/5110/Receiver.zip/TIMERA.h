extern void Delay_10us(unsigned char);
extern void TA1_Init();
extern void Clock_OnTimer();

