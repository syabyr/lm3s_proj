/* $Id: time.c,v 1.2 2009/03/16 20:32:23 simimeie Exp $
 * USB interface for ds1820
 * This file provides time functions.
 * (C) Michael "Fox" Meier 2009
 */

#include <avr/interrupt.h>
#include "time.h"

static volatile uint32_t curts[2] = { 0, 0 };
static volatile uint8_t actts = 0;

void time_init(void) {
  /* Set timer0 to run with CLK/1024. That gives 57.2 Overflow interrupts
   * per second at 15 MHz. */
  TCCR0B |= _BV(2) | _BV(0);
  /* Enable timer interrupts */
  TIMSK |= _BV(1);
}

/* ISR(TIM1_OVF_vect, ISR_NOBLOCK)  doesn't work in the goddamn stoneage ubuntu version */
ISR(TIM0_OVF_vect)
{
  sei(); /* Workaround, should use ISR_NOBLOCK instead */
  {
    uint8_t nextts = (~actts) & 0x01;
    curts[nextts]++;
    actts = nextts;
  }
}

uint32_t gettime(void)
{
  return curts[actts];
}
