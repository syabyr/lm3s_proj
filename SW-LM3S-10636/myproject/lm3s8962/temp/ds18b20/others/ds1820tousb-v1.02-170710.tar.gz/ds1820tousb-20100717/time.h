/* $Id: time.h,v 1.1.1.1 2009/03/15 17:46:59 simimeie Exp $
 * USB interface for ds1820
 * This file provides time functions.
 * (C) Michael "Fox" Meier 2009
 */

#ifndef __TIME_H__
#define __TIME_H__


/* This inits the timer */
void time_init(void);

/* This returns a timestamp. The timestamp increments about 10 times
 * per second. */
uint32_t gettime(void);

#endif /* __TIME_H__ */
