/* $Id: main.c,v 1.5 2010/06/09 23:13:28 simimeie Exp $
 * USB interface for ds1820
 * This is the main file that glues it all together.
 * (C) Michael "Fox" Meier 2009
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <avr/power.h>
#include <avr/sleep.h>
#include <util/delay.h>
#include "usbdrv/usbdrv.h"
#include "ds1820.h"
#include "time.h"

uint8_t doprobescan = 1;
uint8_t curprobe;
uint8_t usbreadpos;
uint32_t readpendingts;
uint8_t readpending;

/* This is needed to recover from a watchdog reset, as the watchdog
 * stays active after the reset. Without this we'll just do an
 * endless reset loop */
void get_mcusr(void) __attribute__((naked)) __attribute__((section(".init3")));
void get_mcusr(void) {
  MCUSR = 0;
  wdt_disable();
}

/* This function is called when the driver receives a SETUP transaction from
 * the host which is not answered by the driver itself (in practice: class and
 * vendor requests). All control transfers start with a SETUP transaction where
 * the host communicates the parameters of the following (optional) data
 * transfer. The SETUP data is available in the 'data' parameter which can
 * (and should) be casted to 'usbRequest_t *' for a more user-friendly access
 * to parameters. [...]
 * in short: Set usbMsgPtr to your answer, and return number of bytes.
 * return USB_NO_MSG to supply the long answer packets with the usbFunctionRead. */
usbMsgLen_t usbFunctionSetup(uchar data[8])
{
  usbRequest_t    *rq = (void *)data;
  static uchar    replyBuf[8];

  if (rq->bRequest == 0){  /* ECHO */
    usbMsgPtr = replyBuf;
    replyBuf[0] = rq->wValue.bytes[0];
    replyBuf[1] = rq->wValue.bytes[1];
    return 2;
  }
  if (rq->bRequest == 1) { /* GET_STATUS_SHORT */
    uint32_t curtime = gettime();
    usbMsgPtr = replyBuf;
    replyBuf[0] = 0; /* Version high */
    replyBuf[1] = 1; /* Version low */
    replyBuf[2] = ((uint8_t *)&curtime)[0];  /* Time */
    replyBuf[3] = ((uint8_t *)&curtime)[1];
    replyBuf[4] = ((uint8_t *)&curtime)[2];
    replyBuf[5] = ((uint8_t *)&curtime)[3];
    replyBuf[6] = DS1820_MAXPROBES;  /* max. number of probes */
    replyBuf[7] = 0; /* UNUSED */
    return 8;
  }
  if (rq->bRequest == 2) { /* RESCAN_BUS */
    usbMsgPtr = replyBuf;
    if (doprobescan) {
      replyBuf[0] = 42; /* Scan already scheduled / in progress */
    } else {
      replyBuf[0] = 23; /* OK, scan scheduled */
      doprobescan = 1;
    }
    return 1;
  }
  if (rq->bRequest == 3) { /* GET_STATUS_LONG */
    /* the answer to this query will list all probes on the bus
     * and thus can be very lengthy. We will handle that with usbFunctionRead */
    usbreadpos = 0;
    return USB_NO_MSG;
  }
  if (rq->bRequest == 4) { /* RESET_HARD */
    /* Reset, both the probe bus and ourselves. We reset ourselves through
     * the watchdog timer and just pull the 1wire bus low. */
    ds1820killbus();
    wdt_reset(); /* Make sure we get the full 2 seconds */
    for (;;) { }
  }
  /* Unknown request. Ignore. */
  return 0;
}

/* This function is called by the driver to ask the application for a control
 * transfer's payload data (control-in). It is called in chunks of up to 8
 * bytes each. You should copy the data to the location given by 'data' and
 * return the actual number of bytes copied. If you return less than requested,
 * the control-in transfer is terminated. If you return 0xff, the driver aborts
 * the transfer with a STALL token. */
uchar usbFunctionRead(uchar *data, uchar len) {
  uint8_t i;
  for (i = 0; i < len; i++) {
    uint8_t j = usbreadpos + i;
    uint8_t probenum = j / 16;
    uint8_t probeoff = j % 16;
    if (probenum >= DS1820_MAXPROBES) {
      return (i - usbreadpos); /* the end - no more data */
    }
    if        (probeoff < 6) {
      data[i] = ds1820probes[probenum].serial[probeoff];
    } else if (probeoff == 6) {
      data[i] = ds1820probes[probenum].family;
    } else if (probeoff == 7) {
      data[i] = ds1820probes[probenum].flags;
    } else if (probeoff == 8) {
      data[i] = ds1820probes[probenum].lasttemp[0];
    } else if (probeoff == 9) {
      data[i] = ds1820probes[probenum].lasttemp[1];
    } else if (probeoff < 14) {
      uint8_t * tp = (uint8_t *)&ds1820probes[probenum].lastts;
      data[i] = tp[probeoff - 10];
    } else {
      data[i] = 0; /* Unused */
    }
  }
  usbreadpos += len;
  return len;
}

int main(void)
{
  /* Some powersaving: Disable unused stuff */
  power_adc_disable();
  power_usi_disable();
  power_timer1_disable();
  
  /* From the avr usb doku wiki: Call usbDeviceDisconnect(), wait several
   * 100 milliseconds and then call usbDeviceConnect(). This enforces
   * (re-)enumeration of the device. In theory, you don't need this, but
   * it prevents inconsistencies between host and device after hardware
   * or watchdog resets. */
  usbDeviceDisconnect();
  _delay_ms(500.0);
  usbDeviceConnect();
  
  /* This function must be called before interrupts are enabled and the main
   * loop is entered. */
  usbInit();
  
  /* Reset if we don't return to the main loop within 2 seconds */
  wdt_enable(WDTO_2S);
  
  /* Init the ds1820 code and bus */
  ds1820init();
  
  /* Init timer */
  time_init();
  
  /* Prepare sleep mode */
  set_sleep_mode(SLEEP_MODE_IDLE);
  sleep_enable();
  
  /* All set up, enable interrupts and go. */
  sei();
  
  while (1) { /* We should never exit, or should we? */
    wdt_reset();
    
    /* This function must be called at regular intervals from the main loop.
     * Maximum delay between calls is somewhat less than 50ms (USB timeout for
     * accepting a Setup message). Otherwise the device will not be recognized.
     * If other functions are called from the USB code, they will be called from
     * usbPoll(). */
    usbPoll();
    
    if ((readpending == 0) && (doprobescan)) {
      ds1820scan();
      doprobescan = 0;
      curprobe = 0;
    } else {
      if (readpending == 0) {
        /* Select next probe to query */
        if ((ds1820probes[curprobe].flags & DS1820FLAG_SLOTINUSE) == DS1820FLAG_SLOTINUSE) {
          ds1820queryprobe(curprobe);
        }
        readpending = 1;
        readpendingts = gettime();
      } else {
        if ((gettime() - readpendingts) > 60) { /* >1 second passed, data should be ready */
          if ((ds1820probes[curprobe].flags & DS1820FLAG_SLOTINUSE) == DS1820FLAG_SLOTINUSE) { /* Is that probe even there? */
            if (ds1820updateprobe(curprobe)) { /* Successful, send updated data */
              if (usbInterruptIsReady()) { /* Last message has been sent, so send new data */
                uint8_t whattosend[8];
                uint8_t i;
                for (i = 0; i < 6; i++) {
                  whattosend[i] = ds1820probes[curprobe].serial[i];
                }
                whattosend[6] = ds1820probes[curprobe].lasttemp[0];
                whattosend[7] = ds1820probes[curprobe].lasttemp[1];
                /* This function sets the message which will be sent during the next interrupt
                 * IN transfer. The message is copied to an internal buffer and must not exceed
                 * a length of 8 bytes. The message may be 0 bytes long just to indicate the
                 * interrupt status to the host.
                 * If you need to transfer more bytes, use a control read after the interrupt.  */
                /* void usbSetInterrupt(uchar *data, uchar len);*/
                usbSetInterrupt(whattosend, 8);
              }
            }
          }
          curprobe++;
          if (curprobe >= DS1820_MAXPROBES) { curprobe = 0; }
          readpending = 0;
        }
      }
    }
    
    /* Go to sleep now */
    sleep_cpu();
  }
  
  /* Never reached */
  return 0;
}
