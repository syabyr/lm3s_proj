#ifndef __IO_H__
#define __IO_H__

#include <cc2430_sfr.h>

#ifndef BV
#define BV(x) (1<<(x))
#endif

#endif /* __IO_H__ */
