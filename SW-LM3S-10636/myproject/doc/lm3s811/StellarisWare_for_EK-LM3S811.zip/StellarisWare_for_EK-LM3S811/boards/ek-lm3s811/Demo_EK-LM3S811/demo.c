
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/adc.h"
#include "inc/lm3s811.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"
#include "inc/hw_ints.h"

unsigned char TIME=0;
#define New_Edition	

#define Blink_First			0
#define Blink_Second		2
#define Blink_Third			4

#define Blue_Blink_Fast		6
#define Green_Blink_Fast	7
#define Red_Blink_Fast		8

#define Blue_Blink_Slow		15
#define Green_Blink_Slow	20
#define Red_Blink_Slow		25

#define All_LED_Close		80

#define LED_Close_Status_A		100
#define LED_Close_Status_B		200

void delay() //������ʱ
{
	int	i=300000;
    while(i>0)	
   	{
		i--;
  	}
}
void O_D2()
{
 	  GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_5,GPIO_PIN_5);
}
void C_D2()
{
	  GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_5,0);
}
void O_L3()
{	  
#ifdef New_Edition
 	  GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0,~0);
#else
	  GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0,0);
#endif
}
void C_L3()
{
#ifdef New_Edition
	  GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0,~GPIO_PIN_0);
#else
	  GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0,GPIO_PIN_0);
#endif
}
void O_L4()
{
#ifdef New_Edition
 	  GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1,~0);
#else
	  GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1,0);
#endif
}
void C_L4()
{
#ifdef New_Edition
	  GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1,~GPIO_PIN_1);
#else
	  GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1,GPIO_PIN_1);
#endif
}
void O_L5()
{	 
#ifdef New_Edition
	  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_0,~0);
#else
 	  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_0,0);
#endif
}
void C_L5()
{
#ifdef New_Edition
	  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_0,~GPIO_PIN_0);
#else
	  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_0,GPIO_PIN_0);
#endif
}
void O_L6()
{
#ifdef New_Edition
 	  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_1,~0);
#else
	  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_1,0);
#endif
}
void C_L6()
{
#ifdef New_Edition
	  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_1,~GPIO_PIN_1);
#else
	  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_1,GPIO_PIN_1);
#endif
}
void O_L7()
{
#ifdef New_Edition
 	  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0,~0);
#else
	  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0,0);
#endif
}
void C_L7()
{
#ifdef New_Edition
	  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0,~GPIO_PIN_0);
#else
	  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0,GPIO_PIN_0);
#endif
}
void O_L8()
{
#ifdef New_Edition
 	  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1,~0);
#else
	  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1,0);
#endif
}
void C_L8()
{
#ifdef New_Edition
	  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1,~GPIO_PIN_1);
#else
	  GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_1,GPIO_PIN_1);
#endif
}
void OA()
{
	  O_L3();O_L4();O_L5();O_D2();O_L6();O_L7();O_L8();
}
void CA()
{
	  C_L3();C_L4();C_L5();C_D2();C_L6();C_L7();C_L8();
}

void
Timer0IntHandler(void)
{
    //
    // ��� Timer �ж�
    //
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	TIME++;
	if(TIME == LED_Close_Status_B)	 // ״̬�� LED_Close_Status_A �� LED_Close_Status_B ֮�䣬LED ʼ��Ϊ���״̬
		TIME = LED_Close_Status_A;


}
void
SysTickIntHandler(void)
{
	if(GPIOPinRead(GPIO_PORTC_BASE,GPIO_PIN_4)==0x00)//��� USER ���Ƿ񱻰���
		TIME=0;	//������ LED ״̬�ı�־����
}
int main(void)
{
	
	SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_6MHZ);//����ϵͳʱ��
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB | SYSCTL_PERIPH_GPIOC | SYSCTL_PERIPH_GPIOD | SYSCTL_PERIPH_GPIOE);//���� GPIO B��C��D �� E
	
	SysTickPeriodSet(SysCtlClockGet() / 20);//����ϵͳ��Сʱ���ж�
    SysTickIntEnable();//������Сʱ���ж�

	GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1);//����PB0��PB1Ϊ���
	GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_5 );//����PC5Ϊ���
	GPIOPinTypeGPIOInput(GPIO_PORTC_BASE, GPIO_PIN_4 );//����PC4Ϊ����
	GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_0 | GPIO_PIN_1);//����PD0��PD1Ϊ���
	GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1);//����PE0��PE1Ϊ���
	
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);//���� Timer0
	
    TimerConfigure(TIMER0_BASE, TIMER_CFG_32_BIT_PER);//���� Timer0 Ϊ 32 λ�Ķ�ʱ��
    TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet()/2);//���� Timer0 ��ʱ��Ϊ 0.5 ��

    //
    // ���� Timer0/SysTick
    //
    IntEnable(INT_TIMER0A);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	SysTickEnable();
	TimerEnable(TIMER0_BASE, TIMER_A);
	
	CA();//�ȹر����е� LED ��

	while(1)
	{
	   //����������
	   if(TIME == Blink_First)
		{			 	
			OA();
		}
		if(TIME == Blink_First+1)
		{			 	
			CA();
		}
	    if(TIME == Blink_Second)
		{			 	
			OA();
		}
		if(TIME == Blink_Second+1)
		{			 	
			CA();
		}
		if(TIME == Blink_Third)
		{			 	
			OA();
		}
		if(TIME == Blink_Third+1)
		{			 	
			CA();
		}
		//����Խǿ���״̬
		if((TIME == Blue_Blink_Fast)||(TIME == Blue_Blink_Fast+3)||(TIME == Blue_Blink_Fast+6))
		{			 	
			O_L3();O_L6();C_L5();C_L8();
		}
		if((TIME == Green_Blink_Fast)||(TIME == Green_Blink_Fast+3)||(TIME == Green_Blink_Fast+6))
		{			 	
			O_L4();O_L7();C_L3();C_L6();
		}
		if((TIME == Red_Blink_Fast)||(TIME == Red_Blink_Fast+3)||(TIME == Red_Blink_Fast+6))
		{			 	
			O_L5();O_L8();C_L4();C_L7();
		}
		//����Խ�����״̬
		if((TIME == Blue_Blink_Slow)||(TIME == Blue_Blink_Slow+15)||(TIME == Blue_Blink_Slow+30)||(TIME == Blue_Blink_Slow+45))
		{			 	
			O_L3();O_L6();delay();C_L5();C_L8();
		}
		if((TIME == Green_Blink_Slow)||(TIME == Green_Blink_Slow+15)||(TIME == Green_Blink_Slow+30)||(TIME == Green_Blink_Slow+45))
		{			 	
			O_L4();O_L7();delay();C_L3();C_L6();
		}
		if((TIME == Red_Blink_Slow)||(TIME == Red_Blink_Slow+15)||(TIME == Red_Blink_Slow+30)||(TIME == Red_Blink_Slow+45))
		{			 	
			O_L5();O_L8();delay();C_L4();C_L7();
		}
		//��ʱ��δ���� USER ������ر����е� LED ��
		if(TIME > All_LED_Close)
		{			 	
			CA();
		}

	};


}
