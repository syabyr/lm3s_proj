Please look in the StellarisWare/boards directory for examples that are
specific to evaluation kits (EK) and reference design kits (RDK).
