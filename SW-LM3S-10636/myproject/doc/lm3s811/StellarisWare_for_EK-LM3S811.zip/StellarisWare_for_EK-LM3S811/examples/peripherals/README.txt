The examples in this directory demonstrate how to program various peripherals
available on Stellaris microcontrollers.  These examples are meant to be used
as guides to follow for your own application.  They will not directly run on
Stellaris evaluation or reference design kits (EK, RDK) without modification.
These are not ready-to-run projects but rather code that you add to your own
project.

For examples that are meant to run directly on kit board, please see the
StellarisWare/boards directory.
