This is Cut down version EVK ,the software package of StellarisWare may can use on this board directly .

You can download original edition CD material from following address : 
http://www.luminarymicro.com/products/ekk-lm3s811_evaluation_kit.html
http://focus.ti.com.cn/cn/docs/toolsw/folders/print/ek-lm3s811.html